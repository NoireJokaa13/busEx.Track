<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Report_Model extends My_Model {
	 protected $table = 'bet_report';
	 protected $primary_key = 'PB_id';
}
?>
